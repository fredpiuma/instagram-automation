import { config } from 'dotenv'
import Instagram from '@utils/util.instagram'
config({ path: '../.env' })

export default async function dotenv () {
  console.log(process.env.IP)
  console.log(Instagram.getServerIP())
  console.log(process.env.IG_USERNAME)
}
