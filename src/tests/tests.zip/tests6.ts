import { IgApiClientBrowser } from './client'
import { Cookie, CookieJar, MemoryCookieStore } from 'tough-cookie'
import follow from '@works/instagram.seguir'
import Instagram from '@utils/util.instagram'
;(async () => {
  const cookies = [
    {
      domain: '.instagram.com',
      expirationDate: 1696870037.7217,
      hostOnly: false,
      httpOnly: false,
      name: 'mid',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value: 'YxTWlQALAAG-w4zI30KKx_Fnjicc',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1696870037.721723,
      hostOnly: false,
      httpOnly: true,
      name: 'ig_did',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value: 'C9FD5470-BDF8-4B85-B8D8-FF2FC42906E5',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1696874634.5714,
      hostOnly: false,
      httpOnly: true,
      name: 'datr',
      path: '/',
      sameSite: 'no_restriction',
      secure: true,
      session: false,
      storeId: '0',
      value: 'iOgUYyNdsn1lkuWrvjOxPJzX',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1662919436.45092,
      hostOnly: false,
      httpOnly: true,
      name: 'shbid',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value:
        '"6389\\05450990265865\\0541693850636:01f75f223ecaf9698e82b3b539254937120acb48d3be6e0107bca7f2d8fbb9ccbdc81005"',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1662919436.45094,
      hostOnly: false,
      httpOnly: true,
      name: 'shbts',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value:
        '"1662314636\\05450990265865\\0541693850636:01f7baa130767f1fa8d0c937fb2d322b5358faed0d45cea2260a4b59bc837a15130d428a"',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1693851738.212138,
      hostOnly: false,
      httpOnly: false,
      name: 'ig_nrcb',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value: '1',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1693774389.889947,
      hostOnly: false,
      httpOnly: false,
      name: 'csrftoken',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value: '9yPQII9mFh4kfG5dzFRIzvUq0taIkm0Y',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1670100789.890013,
      hostOnly: false,
      httpOnly: false,
      name: 'ds_user_id',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value: '50546790780',
    },

    {
      domain: '.instagram.com',
      expirationDate: 1693851746.115924,
      hostOnly: false,
      httpOnly: true,
      name: 'sessionid',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: false,
      storeId: '0',
      value: '50546790780%3ARBroJYiBV6vSca%3A5%3AAYdWfExPFfcNnUEWxRy9tWn9kqnqWAfaaFDrEtT3BA',
    },

    {
      domain: '.instagram.com',
      hostOnly: false,
      httpOnly: true,
      name: 'rur',
      path: '/',
      sameSite: 'unspecified',
      secure: true,
      session: true,
      storeId: '0',
      value:
        '"VLL\\05450546790780\\0541693860789:01f72cca06963e6ff4eb76bd211d47e9c6882bb7b8e75bd809fe4883ad16955838f8a69b"',
    },
  ]

  let result1 = { login: null, follow: null, timeline: null, error: null }

  const avatar = await Instagram.getAvatarInstagramById(494)
  let client

  // await client.state.deserializeCookieJar(avatar.cookie_browser)
  try {
    client = await avatar.getIgApiClientInstance()
    result1.follow = await client.friendship.create('55458713085')
  } catch (error) {
    result1.error = error
  }

  let result2 = { login: null, follow: null, error: null }

  try {
    await client.qe.sync()
    // result1.follow = await client.friendship.create('52526078975')
    result1.timeline = await client.request.send({
      url: '/api/v1/feed/timeline/',
      form: {
        device_id: client.state.deviceId,
        is_async_ads_rti: 0,
        is_async_ads_double_request: 0,
        rti_delivery_backend: 0,
        is_async_ads_in_headload_enabled: 0,
        feed_view_info: [
          {
            media_id: '2920043668317396364_287914102-2920043659895071412_287914102',
            media_pct: 1,
            time_info: { 10: 22920, 25: 22920, 50: 22920, 75: 22920 },
            version: 24,
          },
        ],
      },
    })
  } catch (error) {
    result1.error = { error }
  }

  const client2 = new IgApiClientBrowser()
  try {
    result2.login = await client2.account.login(avatar.usuario, avatar.senha)
    // result2.follow = await client2.friendship.create('52526078975')
  } catch (error) {
    result2.error = error
  }

  console.log(result1)
  console.log(result2)
})()
