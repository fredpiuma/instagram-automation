/* eslint-disable no-unused-vars */
import { AvatarInstagram, InstagramMedia } from '@utils/models'
import Utilidades from '@utils/util'
import Instagram from '@utils/util.instagram'
;(async function () {
  console.log('iniciou')

  let auth
  let challengeStateResponse
  let challengeState
  let lastError
  let requestResponse

  let avatar: AvatarInstagram

  avatar = await Instagram.getAvatarInstagramById(169)

  // avatar.cookie = ''

  let ig = await avatar.getIgApiClientInstance()

  let userInfo = await ig.user.info(avatar.instagram_id)
  let findResult = await ig.user.searchExact('frederico.de.castro')
  let followResult = await ig.friendship.create(findResult.pk)
  let mediaInfo = await ig.media.info(
    Instagram.getMediaIdByMediaCode('Cg9dAFauUDI')
  )
  let instagramMedia = InstagramMedia.fromInstagramRawJson(mediaInfo.items[0])
  let postResult = await ig.publish.photo({
    file: await Utilidades.getFileBufferFromUrl(instagramMedia.images[0].url),
    caption: 'teste de postagem'
  })
  let timeline = ig.feed.user(avatar.instagram_id)
  let timelineResult = await timeline.items()
  if (timelineResult.length) {
    for (const item of timelineResult) {
      let deleteResult = await ig.media.delete({
        mediaId: item.pk
      })
    }
  }
  let destroyFriendshipResult = await ig.friendship.destroy(findResult.pk)

  console.log('fim')
})()
