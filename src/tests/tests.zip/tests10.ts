import { IgApiClientBrowser } from './client'
import { Cookie, CookieJar, MemoryCookieStore } from 'tough-cookie'
import follow from '@works/instagram.seguir'
import Instagram from '@utils/util.instagram'
import Utilidades from '@utils/util'
import { InstagramMedia } from '@utils/models'
;(async () => {
  const avatar = await Instagram.getAvatarInstagramById(374)
  avatar.simulate_browser = true
  let client = <IgApiClientBrowser>await avatar.getIgApiClientInstance()
  let userFeed = client.feed.user('1684144045')
  let medias = await userFeed.items()
  let instagramMedias = medias.map((m) => InstagramMedia.fromInstagramRawJson(m))
  console.log(instagramMedias)
})()
