/* eslint-disable no-unused-vars */
import sizeOf from 'image-size'
import { AvatarInstagram, CookieRoot, CookieTough, InstagramMedia, PerfilInstagram } from '@utils/models'
import Utilidades from '@utils/util'
import Instagram from '@utils/util.instagram'
import { IgApiClient } from 'instagram-private-api'
import { util } from 'prettier'
import { buffer } from 'rxjs'
import { IgApiClientBrowser, PostingAlbumPhotoItem, PostingAlbumVideoItem } from './client'
;(async function () {
  console.log('iniciou')

  const avatar = await Instagram.getAvatarInstagramById(405)

  let cookieRoot: CookieRoot = JSON.parse(avatar.cookie_browser)

  let cookiesTough: CookieTough = JSON.parse(cookieRoot.cookies)

  let updated = false

  if (cookieRoot?.exportedCookies?.length > 0) {
    cookieRoot.exportedCookies.forEach((exportedCookie) => {
      let key = exportedCookie.name.trim()
      let value = exportedCookie.value.trim()
      let fromCookieJar = cookieRoot?.cookieJar?._jar?.cookies.find((c) => c.key === key)
      let fromCookieStore = cookieRoot?.cookieStore?.idx['instagram.com']['/'][key]
      let fromCookies = cookiesTough?.cookies.find((c) => c.key === key)
      if (fromCookieJar) fromCookieJar.value = value
      if (fromCookieStore) fromCookieStore.value = value
      if (fromCookies) fromCookies.value = value
    })
    cookieRoot.cookies = JSON.stringify(cookiesTough)
    delete cookieRoot.exportedCookies
    avatar.cookie_browser = JSON.stringify(cookieRoot)
    await Utilidades.updateSeguroFilter(
      'Avatar_instagram',
      { id: avatar.id },
      { cookie_browser: avatar.cookie_browser }
    )
    await Utilidades.logConsoleAndDatabase({
      code: 'avatar_instagram',
      item_id: avatar.id,
      success: 1,
      type: 'cookie_browser_updated',
      log: 'success',
    })
    updated = true
  } else {
    let userInfo = await Instagram.getUserInfoByUsernameRaw(avatar, 'anitta')
    let target = PerfilInstagram.fromBrowserUserRepositoryInfoByUsernameResponseUser(userInfo)
    if (!userInfo.followed_by_viewer) await Instagram.seguir(avatar, target)
    else await Instagram.deixarDeSeguir(avatar, target)
    console.log(userInfo)
  }

  console.log(updated ? 'updated' : 'not updated')
  /**/
  console.log('fim')
})()
