import Instagram from '@utils/util.instagram'
import InstagramBrowser from '@utils/util.instagram.browser'
;(async () => {
  const avatar = await Instagram.getAvatarInstagramById(374)
  let result = await InstagramBrowser.likeMediaById(avatar, '2918045480081781464')
  console.log(result)
})()
