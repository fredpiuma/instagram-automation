
import Instagram from '@utils/util.instagram';
import request from 'request-promise';
import { IgApiClientBrowser } from './client';

(async () => {
    const avatar = await Instagram.getAvatarInstagramById(493)
    avatar.cookie_browser = '';
    const client = await avatar.getIgApiClientInstance()

    const loginResult = await client.account.login(avatar.usuario, avatar.senha)

    let savedCookies = JSON.parse(avatar.cookie_browser)

    let realCookies = {}
    for (const item of savedCookies.cookieJar._jar.cookies) {
        realCookies[item.key] = item.value
    }

    const cookiesString = new URLSearchParams(realCookies).toString()

    let options = {
        method: 'POST',
        url: 'https://i.instagram.com/api/v1/web/friendships/47810132736/follow/',
        headers: {
            accept: '*/*',
            'accept-language': 'pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'cache-control': 'no-cache',
            'content-length': '0',
            'content-type': 'application/x-www-form-urlencoded',
            cookie: cookiesString,
            pragma: 'no-cache',
            'sec-ch-ua': '"Chromium";v="104", " Not A;Brand";v="99", "Microsoft Edge";v="104"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': savedCookies.userAgent,
            'x-asbd-id': savedCookies.xAsbdId,
            'x-csrftoken': savedCookies.cookieStore,
            'x-ig-app-id': '936619743392459',
            'x-ig-www-claim': 'hmac.AR2rYL8i9mJ9R2GCj6OFdW7mMMm6PTSJsjBa9hHQY8_TKNrG',
            'x-instagram-ajax': '1006140336'
        }
    };

    request(options).then(r => {
        console.log(r);
    }).catch(error => {
        console.log(error);
    })
})()
