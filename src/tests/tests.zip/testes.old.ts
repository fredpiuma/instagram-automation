/* eslint-disable no-unused-vars */
import InstagramClass from '../utils/util.instagram'
import {} from 'instagram-private-api'
const instagram = new InstagramClass()

// (async () => {
//     ip = await utilidades.obterIPDaMaquina();
//     avatares = await instagram.obterAvatares(ip);
//     for (avatar of avatares) {
//         console.log({ "Avatar": avatar.usuario, trabalhos: avatar.trabalhos });
//     }
// }) ();

// console.log(new Date().getMinutes());

// utilidades.obterIPDaMaquina().then((ip) => {
//     instagram.obterAvatar(ip).then(avatar => {
//         console.log(avatar);
//         if (avatar) instagram.obterInformacoesDoPerfilPeloId(avatar.cookie, 232428383).then(r => {
//             console.log(r);
//         });
//     });
// });

// instagram.obterContasDesatualizadasDaBase().then((r) => {
//     console.log(r);
// })

/*
(async () => {
    let ip = await utilidades.obterIPDaMaquina();
    let avatares = await instagram.obterAvatares(ip);
    if (avatares.length) {
        let avatar = avatares.shift();
        perfilAvatar = await instagram.obterPerfilInstagramDoAvatarInstagram(avatar);
        console.log({ username: perfilAvatar.username, id: perfilAvatar.id });
        perfis = await instagram.obterPerfisParaSeguir(avatar, perfilAvatar);
        if (perfis.length) {
            let perfil = perfis.shift();
            console.log({ username: perfil.username, id: perfil.id });
            let result = await instagram.seguir(avatar, perfil);
            console.log(result);
            if (!result.erro) {
                instagram.registrarQueJaSegue(perfilAvatar, perfil, result.result);
            }
        }
    }
})();
/**/

/**/
// utilidades.findSeguro('Mat_trabalho', { nome: 'Fred' }).then((dados) => {
//     for (item of dados) {
//         return utilidades.updateSeguro('Mat_trabalho', item.id, {
//             nome: 'Frederico'
//         }).then((arg) => {
//             console.log(arg);
//         });
//     }
// });

// (async () => {
//     let perfil = await instagram.obterPerfilInstagramPeloId(50196091);
//     let perfilFollower = await instagram.obterPerfilInstagramPeloId(46677298285);
//     let result = await instagram.registrarQueJaSegue(perfilFollower, perfil);
//     console.log(result);
// })();

// (async () => {
//     let perfil = await instagram.obterPerfilInstagramPeloId(50196091);
//     let perfilFollower = await instagram.obterPerfilInstagramPeloId(46677298285);
//     let result = await instagram.registrarQueDeixouDeSeguir(perfilFollower, perfil);
//     console.log(result);
// })();

//   async () => {
//     // return;
//     const ip = await utilidades.obterIPDaMaquina()
//     const avatares = await instagram.obterAvatares(ip)
//     if (avatares.length) {
//       const avatar = avatares.shift()
//       const perfilAvatar = await instagram.obterPerfilInstagramDoAvatarInstagram(
//         avatar
//       )
//       const perfis = await instagram.obterPerfisParaSeguir(avatar, perfilAvatar)
//       if (perfis.length) {
//         const resultado = await instagram.seguir(avatar, perfis[0])
//         if (resultado.status != 'fail') {
//           await instagram.registrarQueJaSegue(perfilAvatar, perfis[0])
//         } else {
//           console.log(resultados)
//         }
//       }
//     }
//   }
// )()

// ;(async () => {
//   // return;
//   const ip = await utilidades.obterIPDaMaquina()
//   const avatares = await instagram.obterAvatares(ip)
//   if (avatares.length) {
//     const avatar = avatares.shift()
//     const perfis = await instagram.obterPerfisParaDeixarDeSeguir(avatar)
//     if (perfis.length) {
//       let resultado = await instagram.deixarDeSeguir(avatar, perfis[0])
//       console.log(resultado)
//       if (!resultado.erro) {
//         resultado = await instagram.registrarQueDeixouDeSeguir(
//           avatar,
//           perfis[0]
//         )
//         console.log(resultado)
//       }
//     }
//   }
// })()
