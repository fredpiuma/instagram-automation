/* eslint-disable no-unused-vars */
import Utilidades from '@utils/util'
import Instagram from '@utils/util.instagram'

import {
  IgApiClient,
  IgResponseError,
  PostingStoryVideoOptions,
  PostingVideoOptions
} from 'instagram-private-api'
import { PublishService } from 'instagram-private-api/dist/services/publish.service'
import { UploadRepository } from 'instagram-private-api/dist/repositories/upload.repository'

;(async function () {
  let upload_id = Date.now().toString()

  const avatar = await Instagram.getAvatarInstagramById(2)
  let client = await avatar.getIgApiClientInstance()

  let reels = await Instagram.getReelsFromUserId(avatar, avatar.instagram_id)
  for (let reel of reels) await Instagram.deleteMediaById(avatar, reel.pk)

  const videoBuffer = Buffer.from(
    await Utilidades.getFileBufferFromUrl(
      'http://dev.surrealgroup.com.br/vertical-curto.mp4'
    )
  )

  let videoInfo = PublishService.getVideoInfo(videoBuffer)

  let result = await client.request.send({
    url: 'rupload_igvideo/fb_uploader_' + upload_id,
    method: 'POST',
    headers: {
      'X-Entity-Type': 'video/mp4',
      offset: 0,
      'X-Entity-Name': 'feed_' + upload_id,
      'X-Entity-Length': videoBuffer.byteLength,
      'Content-Type': 'video/mp4',
      'Content-Length': videoBuffer.byteLength,
      'Accept-Encoding': 'gzip',

      'x-instagram-rupload-params':
        // '{"client-passthrough":"1","is_igtv_video":false,"is_sidecar":"0","is_unified_video":false,"media_type":2,"for_album":false,"video_format":"","upload_id":"' + upload_id + '","upload_media_duration_ms":14720,"upload_media_height":1920,"upload_media_width":1080,"video_transform":null,"is_clips_video":true,"uses_original_audio":true,"audio_type":"original_sounds"}',
        JSON.stringify({
          'client-passthrough': '1',
          is_igtv_video: false,
          is_sidecar: '0',
          is_unified_video: false,
          media_type: 2,
          for_album: false,
          video_format: '',
          upload_id: upload_id,
          upload_media_duration_ms: videoInfo.duration,
          upload_media_height: videoInfo.height,
          upload_media_width: videoInfo.width,
          video_transform: null,
          is_clips_video: true,
          uses_original_audio: true,
          audio_type: 'original_sounds'
        })
    },
    body: videoBuffer
  })

  console.log(result.body)

  await Utilidades.sleep(1e3)

  const coverBuffer = Buffer.from(
    await Utilidades.getFileBufferFromUrl(
      'https://i.pinimg.com/originals/77/96/30/77963020a6397002a14f3a4b711255fe.jpg'
    )
  )

  result = await client.request.send({
    url: 'rupload_igphoto/fb_uploader_' + upload_id,
    method: 'POST',
    headers: {
      'content-type': 'image/jpeg',
      offset: '0',
      'x-entity-length': coverBuffer.byteLength,
      'x-entity-name': 'fb_uploader_' + upload_id,
      'x-entity-type': 'image/jpeg',
      'x-instagram-rupload-params':
        // '{"media_type":2,"upload_id":"' + upload_id + '","upload_media_height":1350,"upload_media_width":1080}'
        JSON.stringify({
          media_type: 2,
          upload_id: upload_id,
          upload_media_height: 1350,
          upload_media_width: 1080
        })
    },
    body: coverBuffer
  })

  console.log(result.body)

  await Utilidades.sleep(1e3)

  result = await client.request.send({
    url: 'api/v1/media/configure_to_clips/',
    method: 'POST',
    headers: {
      offset: '0',
      'content-type': 'application/x-www-form-urlencoded'
    },
    body: [
      // "source_type=library",
      'caption=',
      'upcoming_event=',
      'upload_id=' + upload_id,
      'usertags=',
      'custom_accessibility_caption=',
      'disable_comments=0',
      'like_and_view_counts_disabled=0',
      'igtv_ads_toggled_on=',
      'igtv_share_preview_to_feed=1',
      'is_unified_video=1',
      'video_subtitles_enabled=0',
      'clips_uses_original_audio=1',
      'uses_original_audio=1',
      'original_audio=1',
      'audio=1',
      'clips_audio=1',
      'clips_with_audio=1',
      'with_audio=1',
      'enable_audio=1',
      'clips_enable_audio=1',
      'clips_audio_enable=1',
      'audio_enable=1',
      'audio_type=original_sounds',
      'clips_share_preview_to_feed=1',
      'share_preview_to_feed=1'
    ].join('&')
  })

  console.log(result.body)

  return
})()
