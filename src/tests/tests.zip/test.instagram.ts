/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
import { config } from 'dotenv'
import { readFile } from 'fs'
import { promisify } from 'util'
import { get } from 'request-promise'
import {
  IgApiClient,
  AccountEditProfileOptions,
  DirectThreadBroadcastOptions,
  DirectThreadEntity,
  DirectInboxFeed,
  LikeRequestOptions,
  UserFeedResponseItemsItem
} from 'instagram-private-api'
import {
  AvatarInstagram,
  AvatarInstagramHasMatTrabalho,
  InstagramMedia,
  PerfilInstagram
} from '@utils/models'
import Instagram from '@utils/util.instagram'
import Utilidades from '@utils/util'
config({ path: '../.env' })

/**
 * Generate a usertag
 * @param name - the instagram-username
 * @param x - x coordinate (0..1)
 * @param y - y coordinate (0..1)
 */
async function generateUsertagFromName (
  avatar: AvatarInstagram,
  name: string,
  x: number,
  y: number
): Promise<{ user_id: number; position: [number, number] }> {
  // constrain x and y to 0..1 (0 and 1 are not supported)
  x = clamp(x, 0.0001, 0.9999)
  y = clamp(y, 0.0001, 0.9999)
  // get the user_id (pk) for the name
  const { pk } = await (
    await avatar.getIgApiClientInstance()
  ).user.searchExact(name)
  return {
    user_id: pk,
    position: [x, y]
  }
}

/**
 * Constrain a value
 * @param value
 * @param min
 * @param max
 */
const clamp = (value: number, min: number, max: number) =>
  Math.max(Math.min(value, max), min)

export async function doubleWorkSleepTime () {
  let work: AvatarInstagramHasMatTrabalho = (
    await Instagram.findSeguro('Avatar_instagram_has_mat_trabalho', { id: 497 })
  ).pop()

  work = await Instagram.doubleWorkSleepTime(work)

  console.log(work)
}

export async function changeBiography (txt) {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length > 0) {
    const result = await Instagram.changeBiography(avatares[0], txt)
    console.log(result)
  } else {
    console.log('sem avatares')
  }
}

export async function changeName () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length > 0) {
    const result = await Instagram.changeAccountInfo(avatares[0], {
      full_name: 'Abigail Nicolle Farias'
    })
    console.log(result)
  } else {
    console.log('sem avatares')
  }
}

export async function changePassword () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length > 0) {
    const result = await Instagram.changePassword(avatares[0], 'SL56PkA27nbCA2')
    console.log(result)
  } else {
    console.log('sem avatares')
  }
}

export async function publishPhoto () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length > 0) {
    const readFileAsync = promisify(readFile)
    const ig = await avatares[0].getIgApiClientInstance()
    console.log(process.cwd())
    const file = await readFileAsync('./src/10.jpg')
    const publishResult = await ig.publish.photo({
      // read the file into a Buffer
      file: file,
      // optional, default ''
      caption:
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
      // optional
      // location: mediaLocation,
      // optional
      /*
      usertags: {
        in: [
          // tag the user 'instagram' @ (0.5 | 0.5)
          await generateUsertagFromName(
            avatares[0],
            avatares[0].usuario,
            0.5,
            0.5
          )
        ]
      }
      */
    })
  }
}

export async function repostFeedItemsOnAvatarFeed () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length > 0) {
    const ig = await avatares[0].getIgApiClientInstance()

    const userFeed = ig.feed.user('48198859126')
    let userFeedItems: UserFeedResponseItemsItem[] =
      await Instagram.getAllItemsFromFeed(userFeed)

    userFeedItems = userFeedItems.slice(0, 2)

    for (const item of userFeedItems) {
      const imageBuffer = await get({
        url: item.image_versions2.candidates[0].url,
        encoding: null
      })

      const publishResult = await ig.publish.photo({
        file: imageBuffer,
        caption: item.caption.text
      })
    }
  }
}

export async function checkChallengeState () {
  const avatar = AvatarInstagram.fromJSON(
    (
      await Instagram.findSeguro('Avatar_instagram', {
        usuario: 'esthergiovenardi'
      })
    ).shift()
  )
  console.log(avatar)
  if (avatar.alerta === '1' || avatar.bloqueado === '1') return

  const ig = await avatar.getIgApiClientInstance()
  const users = Array.from((await ig.user.search('funk')).users)
  let i = 0
  try {
    while (users.length > 0) {
      const user = users.shift()
      if (i < 1) {
        console.log(`seguindo: ${user.pk} = ${user.username}`)
        console.log('antes')
        await Instagram.seguir(
          avatar,
          PerfilInstagram.fromUserRepositorySearchResponseUsersItem(user)
        )
        console.log('depois')
      }
      i++
    }
  } catch (error) {
    console.log(error)
    if (error.severity && error.severity === 1) {
      avatar.alerta = '1'
      Instagram.salvarInformacoesDoAvatar(avatar)
    }
  }
  // console.log(ig.state)
}

export async function sendDirect () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    console.log({ avatar })
    Instagram.salvarInformacoesDoAvatar(avatar)
    const perfis: PerfilInstagram[] = await Instagram.findSeguro(
      'Perfil_instagram',
      {
        username: 'anabianovaes'
      }
    )
    if (perfis.length) {
      const perfilAlvo = perfis.shift()
      console.log({ perfilAlvo })
      const ig = await avatar.getIgApiClientInstance()
      const thread = await ig.direct.createGroupThread(
        [perfilAlvo.id + ''],
        'Teste'
      )
      console.log(thread)
      const id = thread.thread_id
      const directThread = ig.entity.directThread(id)
      const mensagem =
        'Bom dia, Bia. Estamos enviando esta mensagem só para te lembrar que a tecnologia da divulgação da promoção está só esperando as definições sua e da Gaby. Este direct é exatamente igual ao direct que será enviado para os clientes, pois está utilizando a tecnologia da Lacir Bacelar & Company.'
      // mensagem = JSON.stringify(perfilAlvo)
      console.log('antes de enviar')
      const enviando = await directThread.broadcastText(mensagem)
      console.log(enviando)
    }
  } else {
    console.log('nenhum avatar encontrado')
  }
}

export async function sendDirectToSpecificPerson () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    const perfis: PerfilInstagram[] = await Instagram.findSeguro(
      'Perfil_instagram',
      {
        username: 'lacirbacelar.company.marketing'
      }
    )
    if (perfis.length) {
      const perfilAlvo = perfis.shift()
      console.log({ perfilAlvo })
      const ig = await avatar.getIgApiClientInstance()
      const thread = await ig.direct.createGroupThread(
        [perfilAlvo.id.toString()],
        perfilAlvo.username
      )
      console.log(thread)
      const id = thread.thread_id
      const directThread = ig.entity.directThread(id)
      const mensagem = 'Teste de mensagem ' + Utilidades.getDateTime()
      // mensagem = JSON.stringify(perfilAlvo)
      console.log('antes de enviar')
      const enviando = await directThread.broadcastText(mensagem)
      console.log(enviando)
    }
  } else {
    console.log('nenhum avatar encontrado')
  }
}

export async function getUserInfo () {
  console.log('oi')
  const avatares = await Instagram.getAvatares('127.0.0.1')
  const perfis = await Instagram.obterContasDesatualizadasDaBase()
  if (avatares.length && perfis.length) {
    const avatar = avatares.shift()
    const perfil = perfis.shift()
    console.log(avatar)
  }
}

export async function getUserInfoByIdFromInstagram (id: string) {
  console.log('oi')
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    try {
      const perfilInstagram = await Instagram.getUserInfoById(avatar, id)
      console.log(perfilInstagram)
    } catch (error) {
      console.log(error)
    }
  } else {
    console.log('sem avatares')
  }
}

export async function likeFirstUserPostTimeline () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  const id = '378353537' /* https://www.instagram.com/animalplanet/?__a=1 */
  if (avatares.length) {
    const avatar = avatares.shift()
    const ig = await avatar.getIgApiClientInstance()
    const items = await Instagram.getUserTimelineMedias(avatar, id)
    await ig.media.like({
      mediaId: items[0].id,
      moduleInfo: {
        module_name: 'profile',
        user_id: (await ig.account.currentUser()).pk,
        username: (await ig.account.currentUser()).username
      },
      d: 0
    })
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function unlikeFirstUserPostTimeline () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  const id = 378353537 /* https://www.instagram.com/animalplanet/?__a=1 */
  if (avatares.length) {
    const avatar = avatares.shift()
    const ig = await avatar.getIgApiClientInstance()
    const userFeed = await ig.feed.user(id)
    const items = await userFeed.items()
    await ig.media.unlike({
      // Like our first post from first page or first post from second page randomly
      mediaId: items[0].id,
      moduleInfo: {
        module_name: 'profile',
        user_id: (await ig.account.currentUser()).pk,
        username: (await ig.account.currentUser()).username
      },
      d: 0
    })
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function getUserTimelinePosts () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  const id = 378353537 /* https://www.instagram.com/animalplanet/?__a=1 */
  if (avatares.length) {
    const avatar = avatares.shift()
    const ig = await avatar.getIgApiClientInstance()
    const userFeed = await ig.feed.user(id)
    const items = await userFeed.items()
    return items
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function getSelfTimelinePosts () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    const ig = await avatar.getIgApiClientInstance()
    const timeline = await ig.feed.timeline()
    const items = await timeline.items()
    return items
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function filterAccountsFollowedBySomeone () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    let accounts = [286465503, 371999617, 371999618]
    accounts = await Instagram.filterAccountsFollowedBySomeone(
      1534835053,
      accounts
    )
    console.log(accounts)
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function getSelfTimelineMediasOnlyPostedByWhoIFollow () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    let medias = await Instagram.getSelfFeedTimelineItems(avatar, 10)
    const perfilDoAvatar =
      await Instagram.obterPerfilInstagramDoAvatarInstagram(avatar)
    medias = await Instagram.filterMediasTakenByAccountsFollowedBySomeone(
      perfilDoAvatar.id,
      medias
    )
    console.log(medias)
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function likeSomeMediaFromAvatarTimeline () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    let medias = await Instagram.getSelfFeedTimelineItems(avatar, 10)
    const perfilDoAvatar =
      await Instagram.obterPerfilInstagramDoAvatarInstagram(avatar)
    medias = await Instagram.filterMediasTakenByAccountsFollowedBySomeone(
      perfilDoAvatar.id,
      medias
    )
    medias = medias.slice(0, Utilidades.getRandomNumber(1, 3))
    while (medias.length > 0) {
      Instagram.likeMediaFromTimeline(avatar, medias.pop())
      Utilidades.sleep(3, 9)
    }
  } else {
    Instagram.logConsoleAndDatabase('sem avatar disponivel')
  }
}

export async function findThreadsAndSaveInBase () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    await Instagram.findForUpdatesInDirectThreads(avatar)
  }
}

export async function likeMediaByCode () {
  const mediaCode = 'CWD8F8pFgy_'
  const mediaId = Instagram.getMediaIdByMediaCode(mediaCode)
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    await Instagram.likeMediaById(avatar, mediaId, 'profile')
  }
}

export async function listMediaFromUserByMediaCode () {
  const mediaCode = 'CWD8F8pFgy_'
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const avatar = avatares.shift()
    const mediaFromCode = await Instagram.getMediaInfoByMediaCode(
      avatar,
      mediaCode
    )
    const mediasFromTimeline = await Instagram.getUserTimelineMedias(
      avatar,
      mediaFromCode.user.pk.toString(),
      12
    )
    const medias = []
    for (const mediaFromTimelie of mediasFromTimeline) {
      medias.push(InstagramMedia.fromUserTimelineItem(mediaFromTimelie))
    }

    await Instagram.saveMediasInBase(medias)
    return medias
  }
}

export async function updateInstagramMediaLike () {
  const avatares = await Instagram.getAvatares('127.0.0.1')
  if (avatares.length) {
    const media = new InstagramMedia()
    media.id = '2603204274008503216'
    const avatar = avatares.shift()
    await Instagram.setMediaToLikeAsLiked(avatar, media)
  }
}
