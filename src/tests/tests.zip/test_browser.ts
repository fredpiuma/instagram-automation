import fetch from 'node-fetch'
import Utilidades from '@utils/util'
import Instagram from '@utils/util.instagram'
import { IgApiClientBrowser } from '../client'
;(async function () {
  console.log('iniciou')

  let avatar = await Instagram.getAvatarInstagramById(328)

  if (avatar.simulate_browser !== true) {
    console.log('avatar.simulate_browser!==true')
    return
  } else {
    let client = (await avatar.getIgApiClientInstanceBrowser()) as IgApiClientBrowser
    let followResult = await client.friendship.create('48198859126')
    console.log(followResult)
  }

  return

  // console.log('fim')
})()
