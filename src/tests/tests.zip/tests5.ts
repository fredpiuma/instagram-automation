
import Instagram from '@utils/util.instagram';
import request from 'request-promise';
import { IgApiClientBrowser } from './client';

(async () => {
    const avatar = await Instagram.getAvatarInstagramById(348)

    let client = <IgApiClientBrowser> await avatar.getIgApiClientInstance()
    await client.qe.sync()
    // let bkp1 = await client.state.serialize()
    await client.qe.sync()
    // let bkp2 = await client.state.serialize()
    await client.qe.sync()
})()
