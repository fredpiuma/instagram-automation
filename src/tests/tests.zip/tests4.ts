import Instagram from '@utils/util.instagram'
import request from 'request-promise'
import { IgApiClientBrowser } from './client'
;(async () => {
  try {
    const avatar = await Instagram.getAvatarInstagramById(111111111111)
    // avatar.cookie_browser = ''

    const avatarProfile = await Instagram.obterPerfilInstagramDoAvatarInstagram(avatar)

    const perfis = await Instagram.getInstagramProfilesToFollow(avatar, avatarProfile)

    const profile = perfis.shift()

    const client = <IgApiClientBrowser>await avatar.getIgApiClientInstance()
    await client.qe.sync()

    let result = await Instagram.seguir(avatar, profile)
    let friendship = result.following ? 'following' : 'requested'

    await Instagram.registrarQueJaSegue(avatarProfile, profile, friendship, true)

    result = await Instagram.seguir(avatar, profile)
    friendship = result.following ? 'following' : 'requested'

    await Instagram.registrarQueJaSegue(avatarProfile, profile, friendship, true)
  } catch (error) {
    console.log(error)
  }
})()
