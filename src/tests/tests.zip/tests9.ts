import { IgApiClientBrowser } from './client'
import { Cookie, CookieJar, MemoryCookieStore } from 'tough-cookie'
import follow from '@works/instagram.seguir'
import Instagram from '@utils/util.instagram'
import Utilidades from '@utils/util'
import { InstagramMedia } from '@utils/models'
;(async () => {
  const avatar = await Instagram.getAvatarInstagramById(374)
  avatar.simulate_browser = true
  let client = <IgApiClientBrowser>await avatar.getIgApiClientInstance()
  let result = await client.user.info('287914102')
  console.log(result)
})()
