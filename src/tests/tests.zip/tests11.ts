import { IgApiClientBrowser } from './client'
import { Cookie, CookieJar, MemoryCookieStore } from 'tough-cookie'
import Instagram from '@utils/util.instagram'
import Utilidades from '@utils/util'
import { InstagramMedia } from '@utils/models'
import follow from '@works/instagram.seguir'
;(async () => {
  const avatar = await Instagram.getAvatarInstagramById(374)
  avatar.simulate_browser = true
  await follow(avatar)
})()
