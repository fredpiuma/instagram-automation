import { AvatarInstagram } from '@utils/models'
import InstagramBrowser from '@utils/util.instagram.browser'
import {} from 'dotenv/config'

export default async function instagramRegistrarStatusDoPerfilDoAvatar(
  avatar: AvatarInstagram
): Promise<AvatarInstagram> {
  InstagramBrowser.logConsole(avatar.usuario, 'avatar_instagram_historico')
  try {
    avatar.instagram_id = await InstagramBrowser.getInstagramIdFromAvatar(avatar)
    avatar = await InstagramBrowser.getUserInfoFromInstagramAndRegisterInBase(avatar, {
      id: avatar.instagram_id,
      username: avatar.usuario
    })
    return avatar
  } catch (error) {
    const situation = await InstagramBrowser.dealWithSituation(error, avatar)

    if (situation.needLogout) avatar.bloqueado = '1'

    return avatar
  }
}
