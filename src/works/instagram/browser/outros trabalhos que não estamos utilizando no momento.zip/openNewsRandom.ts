/* eslint-disable no-unused-vars */
import { AvatarInstagram } from '@utils/models'
import Utilidades from '@utils/util'
import Instagram from '@utils/util.instagram'
import Works from './works'

export default async function openNewsRandom(
  avatar: AvatarInstagram
): Promise<AvatarInstagram> {
  const work = avatar.getWork(Works.InstagramOpenNewsRandom)
  if (!avatar.isReady() || !work) return avatar

  let news

  try {
    if (Utilidades.getRandomNumber(1, 5) === 5) {
      news = await Instagram.getNews(avatar)
    } else {
      // Utilidades.logConsole('no timeline')
    }

    return avatar
  } catch (error) {
    const situation = await Instagram.dealWithSituation(
      error,
      avatar,
      work,
      true
    )

    if (situation.needLogout) avatar.bloqueado = '1'

    return avatar
  }
}
