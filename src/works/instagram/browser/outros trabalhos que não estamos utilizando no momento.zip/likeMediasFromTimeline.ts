/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
import { AvatarInstagram, PerfilInstagram } from '@utils/models'
import { TimelineFeedResponseMedia_or_ad } from 'instagram-private-api'
import Works from '@works/works'
import InstagramBrowser from '@utils/util.instagram.browser'

export default async function trabalho(avatar: AvatarInstagram): Promise<AvatarInstagram> {
  const work = avatar.getWork(Works.instagramLikeMediasFromTimeline)
  if (!avatar.isReady() || !work) return avatar

  if (InstagramBrowser.getRandomNumber(1, 5) === 3) return avatar

  await InstagramBrowser.logConsoleAndDatabase({
    code: 'avatar_instagram',
    item_id: avatar.id,
    type: work.mat_trabalho.nome,
    success: 1,
    log: 'start'
  })

  try {
    let medias = await InstagramBrowser.getSelfFeedTimelineItems(avatar, 15)

    if (InstagramBrowser.getRandomNumber(0, 1) === 0) {
      await InstagramBrowser.sleep(work.dormir_de * 60e3, work.dormir_ate * 60e3, avatar.usuario)
      return avatar
    }

    const perfilDoAvatar = await InstagramBrowser.obterPerfilInstagramDoAvatarInstagram(avatar)
    medias = await InstagramBrowser.filterMediasTakenByAccountsFollowedBySomeone(perfilDoAvatar.id, medias)

    if (medias.length === 0) {
      //   await InstagramBrowser.logConsoleAndDatabase({
      //     code: 'avatar_instagram',
      //     item_id: avatar.id,
      //     type: work.mat_trabalho.nome,
      //     success: 0,
      //     log: 'no medias to like'
      //   })
      return avatar
    }

    /* reduzido de 1 a 3 para 1 por ter levado bloqueio de spam em alguns avatares */
    medias = medias.slice(0, 1 /* InstagramBrowser.getRandomNumber(1, 3) */)
    let media: TimelineFeedResponseMedia_or_ad
    if (medias.length) {
      while ((media = medias.shift())) {
        const liked = await InstagramBrowser.likeMediaFromTimeline(avatar, media)
        if (medias.length) {
          await InstagramBrowser.sleep(3 * 6e3, 9 * 6e3, avatar.usuario)
        }
      }
    }
    await InstagramBrowser.sleep(work.dormir_de * 60e3, work.dormir_ate * 60e3, avatar.usuario)
    return avatar
  } catch (error) {
    const situation = await InstagramBrowser.dealWithSituation(error, avatar, work)

    if (situation.needLogout) avatar.bloqueado = '1'

    return avatar
  }
}
