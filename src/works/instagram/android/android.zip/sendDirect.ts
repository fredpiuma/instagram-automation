// eslint-disable-next-line no-unused-vars
import { AvatarInstagram, PerfilInstagram } from '@utils/models'
import Utilidades from '@utils/util'
import Instagram from '../utils/util.instagram'
import Works from './works'

export default async function enviarDirect(
  avatar: AvatarInstagram
): Promise<AvatarInstagram> {
  const work = avatar.getWork(Works.InstagramEnviarDirect)
  if (!avatar.isReady() || !work) return avatar
  // Instagram.logConsole(avatar.usuario, work.mat_trabalho.nome)
  let profileIdsToSend, profileIdToSend

  const workDetails = {
    type: work.mat_trabalho.nome,
    target: null,
    message: null
  }

  try {
    profileIdsToSend = await Instagram.getAccountsToSendDirect(avatar)

    if (profileIdsToSend.length) {
      while ((profileIdToSend = profileIdsToSend.shift())) {
        const directMessages = await Instagram.getDirectMessageToSend(avatar)
        if (directMessages.length > 0) {
          const directMessage = directMessages.shift()
          /* replace #### sequence for a specific number */
          directMessage.mensagem = directMessage.mensagem.replace(
            /####+/,
            profileIdToSend.toString().substring(0, 6)
          )

          const messageParts = directMessage.mensagem
            .split('|||')
            .map((txt) => txt.trim())
          let messagePart

          if (messageParts.some((txt) => txt.length > 1000)) {
            directMessage.mensagem = directMessage.mensagem.replace(
              /\|\|\|/g,
              ''
            )
            if (directMessage.mensagem.length > 1000) {
              while (directMessage.mensagem.length > 1000) {
                const linkPosition =
                  500 + directMessage.mensagem.substring(500).indexOf('\n')
                messagePart = directMessage.mensagem.substring(0, linkPosition)
                messageParts.push(messagePart.trim())
                directMessage.mensagem = directMessage.mensagem
                  .substring(messagePart.length)
                  .trim()
              }
              if (directMessage.mensagem.length > 0) {
                messageParts.push(directMessage.mensagem.trim())
              }
            }
          }

          while (messageParts.length) {
            messagePart = messageParts.shift()
            workDetails.message = messagePart
            workDetails.target = profileIdToSend
            await Instagram.sendDirect(avatar, profileIdToSend, messagePart)

            if (messageParts.length > 0) await Utilidades.sleep(5e3, 10e3)
          }

          await Instagram.registerSentMessage(
            avatar,
            directMessage,
            profileIdToSend
          )
        }
        if (profileIdsToSend.length) {
          await Instagram.sleep(30e3, 60e3)
        }
      }
    }
    await Instagram.sleep(
      work.dormir_de * 60e3,
      work.dormir_ate * 60e3,
      avatar.usuario
    )
    return avatar
  } catch (error) {
    if (
      error.name === 'IgResponseError' &&
      !(await Instagram.perfilInstagramExists(avatar, workDetails.target))
    ) {
      await Instagram.deletePerfilInstagram({ id: workDetails.target })
      await Instagram.logConsoleAndDatabase({
        code: 'avatar_instagram',
        item_id: avatar.id,
        type: workDetails.type,
        success: 0,
        log: {
          target: workDetails.target,
          directMessage: workDetails.message,
          name: error.name,
          message: error.message,
          stack: error.stack,
          work: work || null
        }
      })
      return avatar
    } else if (
      error.name === 'IgResponseError' &&
      error.message.includes('500 Internal Server Error')
    ) {
      await Instagram.logConsoleAndDatabase({
        code: 'avatar_instagram',
        item_id: avatar.id,
        type: workDetails.type,
        success: 0,
        log: {
          target: workDetails.target,
          directMessage: workDetails.message,
          name: error.name,
          message: error.message,
          stack: error.stack,
          work: work || null
        }
      })
      return avatar
    }

    const situation = await Instagram.dealWithSituation(
      error,
      avatar,
      work,
      true
    )

    if (situation.needLogout) avatar.bloqueado = '1'

    if (situation.error.message.includes('Unloadable participant')) {
      //   Instagram.logConsole(
      //     'Possível conta inexistente, vai apagar da base',
      //     profileIdToSend
      //   )
      await Instagram.deleteSeguro('Perfil_instagram', {
        id: profileIdToSend
      })
    }
    return avatar
  }
}
