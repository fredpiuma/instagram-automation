import {} from 'dotenv/config'
import { AvatarInstagram } from '@utils/models'
import Instagram from '@utils/util.instagram'
import Utilidades from '@utils/util'

export default async function instagramRegistrarStatusDoPerfilDoAvatar(
  avatar: AvatarInstagram
): Promise<AvatarInstagram> {
  Utilidades.logConsole(avatar.usuario, 'avatar_instagram_historico')
  try {
    avatar.instagram_id = await Instagram.getInstagramIdFromAvatar(avatar)
    avatar = await Instagram.getUserInfoFromInstagramAndRegisterInBase(avatar, {
      id: avatar.instagram_id,
      username: avatar.usuario,
    })
    return avatar
  } catch (error) {
    const situation = await Instagram.dealWithSituation(error, avatar)

    if (situation.needLogout) avatar.bloqueado = '1'

    return avatar
  }
}
