import {} from 'dotenv/config'
// eslint-disable-next-line no-unused-vars
import { AvatarInstagram, PerfilInstagram } from '../../../utils/models'
import Instagram from '../../../utils/util.instagram'
import Works from '../../works'

export default async function instagramAtualizarLeads(avatar: AvatarInstagram): Promise<AvatarInstagram> {
  const work = avatar.getWork(Works.InstagramAtualizarLeads)
  if (!avatar.isReady() || !work) return avatar

  // Instagram.logConsole(avatar.usuario, Works.InstagramAtualizarLeads)

  let conta: PerfilInstagram

  try {
    const contas = await Instagram.obterContasDesatualizadasDaBase()

    // Instagram.logConsole(
    // 	`${contas.length} contas a serem atualizadas: ${contas
    // 		.map((c) => `${c.id}`)
    // 		.join(', ')}`
    // )

    if (contas.length) {
      while ((conta = contas.shift())) {
        if (conta && conta.id) {
          const perfil = await Instagram.getUserInfoById(avatar, conta.id.toString())
          //   Instagram.logConsole(
          //     `conta atualizada: ${perfil.id} : ${perfil.username}`
          //   )
          await Instagram.salvarInformacoesDoUsernameNaBase(perfil)
          if (contas.length > 0) await Instagram.sleep(30e3, 60e3)
        }
      }

      await Instagram.sleep(work.dormir_de * 60e3, work.dormir_ate * 60e3, avatar.usuario)
      return avatar
    }
  } catch (error) {
    const situation = await Instagram.dealWithSituation(error, avatar, work)

    if (situation.needLogout) avatar.bloqueado = '1'

    if (situation.type === 'IgNotFoundError') {
      await Instagram.deletePerfilInstagram(conta)
    }

    return avatar
  }
}
