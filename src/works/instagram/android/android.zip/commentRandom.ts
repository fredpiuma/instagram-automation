/* eslint-disable no-unused-vars */
import { AvatarInstagram, InstagramMedia } from '@utils/models'
import Utilidades from '@utils/util'
import Instagram from '@utils/util.instagram'
import Works from './works'

export default async function commentRandom(
  avatar: AvatarInstagram
): Promise<AvatarInstagram> {
  const work = avatar.getWork(Works.InstagramCommentRandom)
  if (!avatar.isReady() || !work) return avatar

  let medias: InstagramMedia[]
  let media: InstagramMedia

  try {
    medias = await Instagram.getMediasToCommentRandom(avatar)

    if (medias.length) {
      for (media of medias) {
        const comment = await Instagram.postComment(avatar, {
          mediaId: media.id,
          text: '🤘\n#VixMusicaAoVivo'
        })

        await Utilidades.insertSeguro('Instagram_comment', comment)

        await Instagram.sleep(
          work.dormir_de * 60e3,
          work.dormir_ate * 60e3,
          `${avatar.usuario} - ${work.mat_trabalho.nome}`
        )
      }
    } else {
      //   Utilidades.logConsole(avatar.usuario, 'no medias to comment')
    }

    return avatar
  } catch (error) {
    if (
      /\/api\/v1\/media\/[0-9]+\/like\//.test(error.stack) &&
      error.text === 'Sorry, this media has been deleted'
    ) {
      await Utilidades.deleteSeguro('Instagram_media', { id: media.id })
    } else {
      const situation = await Instagram.dealWithSituation(
        error,
        avatar,
        work,
        true
      )

      if (situation.needLogout) avatar.bloqueado = '1'
    }
    return avatar
  }
}
