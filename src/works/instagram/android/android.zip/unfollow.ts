// eslint-disable-next-line no-unused-vars
import { AvatarInstagram, PerfilInstagram } from '@utils/models'
import Utilidades from '@utils/util'
import Instagram from '../utils/util.instagram'
import Works from './works'

export default async function deixarDeSeguir(
  avatar: AvatarInstagram
): Promise<AvatarInstagram> {
  const work = avatar.getWork(Works.InstagramDeixarDeSeguir)
  if (!avatar.isReady() || !work) return avatar

  // let mainJob = { type: null, target: null }
  let profilesToUnfollow: PerfilInstagram[], profileToUnfollow: PerfilInstagram

  try {
    profilesToUnfollow = await Instagram.obterPerfisParaDeixarDeSeguir(avatar)

    if (profilesToUnfollow.length) {
      await Utilidades.logConsoleAndDatabase({
        code: 'avatar_instagram',
        item_id: avatar.id,
        type: work.mat_trabalho.nome,
        success: 1,
        log: 'start'
      })
    } else {
      // Instagram.logConsole(
      //   avatar.usuario,
      //   work.mat_trabalho.nome,
      //   'nobody to unfollow'
      // )
      return avatar
    }

    while ((profileToUnfollow = profilesToUnfollow.shift())) {
      /* 2022-08-07 10:34 desativamos o getFriendshipStatusRaw por termos identificado que tem dado muitos checkpoints */
      // let friendshipStatus = await Instagram.getFriendshipStatusRaw(
      //   avatar,
      //   profileToUnfollow.id.toString()
      // )

      // if (friendshipStatus.followed_by) {
      //   let friendshipStatusFromBase = await Utilidades.findSeguro(
      //     'Perfil_instagram_has_perfil_instagram',
      //     {
      //       perfil_instagram_id: avatar.instagram_id,
      //       perfil_instagram_follower_id: profileToUnfollow.id
      //     }
      //   )
      //   if (friendshipStatusFromBase.length === 0) {
      //     await Utilidades.insertSeguro(
      //       'Perfil_instagram_has_perfil_instagram',
      //       {
      //         perfil_instagram_id: avatar.instagram_id,
      //         perfil_instagram_follower_id: profileToUnfollow.id,
      //         data_pagination: Utilidades.getDateTime(),
      //         status: 'following'
      //       }
      //     )
      //   } else {
      //     if (friendshipStatusFromBase[0].data_pagination === null) {
      //       await Utilidades.updateSeguroFilter(
      //         'Perfil_instagram_has_perfil_instagram',
      //         {
      //           perfil_instagram_id: avatar.instagram_id,
      //           perfil_instagram_follower_id: profileToUnfollow.id
      //         },
      //         {
      //           data_pagination: Utilidades.getDateTime()
      //         }
      //       )
      //     }
      //   }
      // }

      await Instagram.deixarDeSeguir(avatar, profileToUnfollow)

      await Instagram.registrarQueDeixouDeSeguir(avatar, profileToUnfollow)

      if (profilesToUnfollow.length) {
        await Instagram.sleep(30e3, 60e3, avatar.usuario)
      } else {
        await Instagram.sleep(
          work.dormir_de * 60e3,
          work.dormir_ate * 60e3,
          avatar.usuario
        )
      }
    }
    return avatar
  } catch (error) {
    const situation = await Instagram.dealWithSituation(
      error,
      avatar,
      work,
      true
    )

    if (situation.needLogout) avatar.bloqueado = '1'

    if (
      situation.type === 'IgNotFoundError' ||
      situation.type === 'IgResponseError'
    ) {
      /* 2022-08-03 não deleta mais o perfil_instagram, apenas deleta a relação de amizade */
      await Instagram.deleteSeguro('Perfil_instagram_has_perfil_instagram', {
        perfil_instagram_id: profileToUnfollow.id,
        perfil_instagram_follower_id: avatar.instagram_id
      })
      //   await Instagram.deletePerfilInstagram(profileToUnfollow)
    }

    return avatar
  }
}
